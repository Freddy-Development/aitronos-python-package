
# Setup basic logging
