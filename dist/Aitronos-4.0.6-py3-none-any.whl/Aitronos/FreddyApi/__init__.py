from .module import FreddyApi

__version__ = "0.0.1"
__all__ = ["FreddyApi"]
