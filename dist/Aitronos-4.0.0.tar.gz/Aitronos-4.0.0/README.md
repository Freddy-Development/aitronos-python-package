# Aitronos-python-package
The freddy and other aitronos apis put in a neat package 
